from django.conf.urls import include, url
from . import views

urlpatterns = [

    url(r'^main/$',views.hello),
    url(r'^index/$', views.index)
]