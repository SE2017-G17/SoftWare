class HtmlOutputer(object):
    def __init__(self):
        self.datas = []  # �б�

    # �ռ�����
    def collect_data(self, data):
        if data is None:
            return
        self.datas.append(data)

    # ���HTML����
    def output_html(self):
        fout = open('output.html', 'w', encoding='utf-8')  # �����output.html��,wΪдģʽ

        fout.write("<html>")
        fout.write("<body>")
        fout.write("<meta charset=UTF-8>")
        fout.write("<table>")

        # ASCI
        for data in self.datas:
            fout.write("<tr>")
            fout.write("<td>%s</td>" % data['title'])
            fout.write("<td>%s</td>" % data['summary'])
            fout.write("</tr>")

        fout.write("</table>")
        fout.write("</body>")
        fout.write("</html>")

        fout.close()

