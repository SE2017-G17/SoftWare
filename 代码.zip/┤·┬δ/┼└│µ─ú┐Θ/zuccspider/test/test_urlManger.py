from unittest import TestCase


class TestUrlManger(TestCase):
    def test_add_new_url(self):
        self.fail()

    def test_add_new_urls(self):
        self.fail()

    def test_has_new_url(self):
        self.fail()

    def test_get_new_url(self):
        self.fail()
