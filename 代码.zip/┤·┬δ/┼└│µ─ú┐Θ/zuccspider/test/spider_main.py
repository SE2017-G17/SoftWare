from test import html_download, html_parser, html_outerput, html_pase2
from test import url_manger
class SpiderMain(object):
    def __init__(self):
        self.urls = url_manger.UrlManger()

        self.downloader = html_download.HtmlDownload()

        self.parser = html_parser.HtmlParser()

        self.outputer = html_outerput.HtmlOutputer()

        self.paser_data = html_pase2.HtmlPaserData()

    def craw(self, root_url):
        self.urls.add_new_url(root_url)

        new_url = self.urls.get_new_url()

        html_cont = self.downloader.download(new_url)

        new_urls = self.parser.parser(new_url, html_cont)

        self.urls.add_new_urls(new_urls)

        while self.urls.has_new_url():
            new_url2 = self.urls.get_new_url()

            html_cont2 = self.downloader.download(new_url2)

            new_data = self.paser_data.newsdata(new_url2, html_cont2)

            self.outputer.collect_data(new_data)








        self.outputer.output_html()


if __name__ == "__main__":
    root_url = "http://jsxy.zucc.edu.cn/index.html"
    obj_spider = SpiderMain()
    obj_spider.craw(root_url)

