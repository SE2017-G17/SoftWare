from bs4 import BeautifulSoup
import re
import urllib


class HtmlPaserData(object):
    def _get_new_data(self, page_url, soup):
        res_data = {}
        res_data['url'] = page_url
        title_node = soup.find('td', class_="title")

        res_data['title'] = title_node.get_text()
        print(title_node.get_text())
        summary_node = soup.find('div', id="zoom")

        res_data['summary'] = summary_node.get_text()

        return res_data

    def newsdata(self, page_url, html_cont2):
        soup = BeautifulSoup(html_cont2, 'lxml')
        new_data = self._get_new_data(page_url, soup)
        return new_data